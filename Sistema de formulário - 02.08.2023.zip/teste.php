<?php
// Conecte-se ao banco de dados do SSMS
$conn = new mysqli('127.0.0.1:3306', 'u857252213_host', 'BrunoAugusto1', 'u857252213_host');

// Verifique se ocorreu algum erro na conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Recebe os dados do formulário
$nome = $_POST['nome'];
$email = $_POST['email'];

// Insere os dados na tabela "clientes"
$sql = "INSERT INTO clientes (nome, email) VALUES ('$nome', '$email')";

if ($conn->query($sql) === TRUE) {
    echo "Dados inseridos com sucesso!";
} else {
    echo "Erro ao inserir dados: " . $conn->error;
}

$conn->close();

// Execute uma consulta para recuperar os dados da tabela clientes
$sql = "SELECT * FROM clientes";
$result = $conn->query($sql);

// Crie uma tabela HTML para exibir os resultados
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Nome</th><th>Email</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["nome"] . "</td><td>" . $row["email"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "Nenhum resultado encontrado.";
}

// Feche a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Exemplo de Visualização de Banco de Dados do SSMS</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            text-align: left;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <form method="post" action="processa.php">
  <label for="nome">Nome:</label>
  <input type="text" id="nome" name="nome">
  
  <label for="email">E-mail:</label>
  <input type="email" id="email" name="email">
  
  <input type="submit" value="Enviar">
</form>

</body>
</html>
