
$(document).ready(function() {
    
    
    
    $('#contact_form').bootstrapValidator({
        
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                        stringLength: {
                        min: 1,
                        
                    },
                        notEmpty: {
                        message: 'Preencha este campo'
                    }
                }
            },
             last_name: {
                validators: {
                     stringLength: {
                        min: 11,
                        message: 'Preencha este campo completamente',
                    },
                    notEmpty: {
                        message: 'Preencha este campo completamente'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Insira corretamente o e-mail'
                    },
                    emailAddress: {
                        message: 'Insira corretamente o e-mail'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your phone number'
                    },
                    phone: {
                        country: 'US',
                        message: 'Insira um número válido'
                    }
                }
            },
            address: {
                validators: {
                     stringLength: {
                        min: 1,
                        message: 'Preencha este campo completamente',
                    },
                    notEmpty: {
                        message: 'Insira o endereço completo'
                    }
                }
            },
            cep: {
                validators: {
                     stringLength: {
                        min: 8,
                        message: 'Preencha este campo completamente',
                    },
                    notEmpty: {
                        message: 'Insira o endereço completo'
                    }
                }
            },
            city: {
                validators: {
                     stringLength: {
                        min: 4,
                    },
                    notEmpty: {
                        message: 'Please supply your city'
                    }
                }
            },
            state: {
                validators: {
                    notEmpty: {
                        message: 'Please select your state'
                    }
                }
            },
            zip: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your zip code'
                    },
                    zipCode: {
                        country: 'US',
                        message: 'Please supply a vaild zip code'
                    }
                }
            },
            
            }
        })

        
        .on('success.form.bv', function(e) {
 
              
        });
});


