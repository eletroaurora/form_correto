<?php

if(isset($_POST['enviar'])) {
  $para = 'pamela@eletroaurora.com.br, solar@eletroaurora.com.br';
  $assunto = 'Solicitacao de contrato: ';
  $mensagem = 'Olá! Tudo bem? Segue em anexo as documentações necessárias para o contrato!';

  // Verificar se os arquivos foram enviados
  if(isset($_FILES['arquivo1']) && $_FILES['arquivo1']['error'] == 0
    && isset($_FILES['arquivo2']) && $_FILES['arquivo2']['error'] == 0
    && isset($_FILES['arquivo3']) && $_FILES['arquivo3']['error'] == 0
    && isset($_FILES['arquivo4']) && $_FILES['arquivo4']['error'] == 0) {

    // Dados do primeiro arquivo
    $arquivo1_tmp = $_FILES['arquivo1']['tmp_name'];
    $arquivo1_nome = $_FILES['arquivo1']['name'];
    $arquivo1_tipo = $_FILES['arquivo1']['type'];
    $arquivo1_tamanho = $_FILES['arquivo1']['size'];

    // Dados do segundo arquivo
    $arquivo2_tmp = $_FILES['arquivo2']['tmp_name'];
    $arquivo2_nome = $_FILES['arquivo2']['name'];
    $arquivo2_tipo = $_FILES['arquivo2']['type'];
    $arquivo2_tamanho = $_FILES['arquivo2']['size'];

    // Dados do terceiro arquivo
    $arquivo3_tmp = $_FILES['arquivo3']['tmp_name'];
    $arquivo3_nome = $_FILES['arquivo3']['name'];
    $arquivo3_tipo = $_FILES['arquivo3']['type'];
    $arquivo3_tamanho = $_FILES['arquivo3']['size'];

    // Dados do quarto arquivo
    $arquivo4_tmp = $_FILES['arquivo4']['tmp_name'];
    $arquivo4_nome = $_FILES['arquivo4']['name'];
    $arquivo4_tipo = $_FILES['arquivo4']['type'];
    $arquivo4_tamanho = $_FILES['arquivo4']['size'];

    // Dados do quinto arquivo
    $arquivo5_tmp = $_FILES['arquivo5']['tmp_name'];
    $arquivo5_nome = $_FILES['arquivo5']['name'];
    $arquivo5_tipo = $_FILES['arquivo5']['type'];
    $arquivo5_tamanho = $_FILES['arquivo5']['size'];
    
    // Dados do quinto arquivo
    $arquivo6_tmp = $_FILES['arquivo6']['tmp_name'];
    $arquivo6_nome = $_FILES['arquivo6']['name'];
    $arquivo6_tipo = $_FILES['arquivo6']['type'];
    $arquivo6_tamanho = $_FILES['arquivo6']['size'];

    // Ler o conteúdo dos arquivos em objetos de fluxo de dados
    $arquivo1 = file_get_contents($arquivo1_tmp);
    $arquivo2 = file_get_contents($arquivo2_tmp);
    $arquivo3 = file_get_contents($arquivo3_tmp);
    $arquivo4 = file_get_contents($arquivo4_tmp);
    $arquivo5 = file_get_contents($arquivo5_tmp);
    $arquivo6 = file_get_contents($arquivo6_tmp);

    // Gerar um limite de multipart/form-data
    $limite = md5(uniqid(time()));

    // Cabeçalhos do email
    $cabecalhos = "MIME-Version: 1.0\r\n";
    $cabecalhos .= "Content-Type: multipart/mixed; boundary=\"{$limite}\"\r\n";
    $cabecalhos .= "From: formulario@eletroaurora.com\r\n";

    // Corpo do email
    $corpo = "--{$limite}\r\n";
    $corpo .= "Content-Type: text/plain; charset=\"utf-8\"\r\n";
    $corpo .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $corpo .= "{$mensagem}\r\n\r\n";

    // Anexos do email
    $corpo .= "--{$limite}\r\n";
    $corpo .= "Content-Type: {$arquivo1_tipo}; name=\"{$arquivo1_nome}\"\r\n";
    $corpo .= "Content-Transfer-Encoding: base64\r\n";
    $corpo .= "Content-Disposition: attachment; filename=\"CONTA DE ENERGIA\"\r\n\r\n";
    $corpo .= chunk_split(base64_encode($arquivo1));
    $corpo .= "--{$limite}\r\n";
    $corpo .= "Content-Type: {$arquivo2_tipo}; name=\"{$arquivo2_nome}\"\r\n";
    $corpo .= "Content-Transfer-Encoding: base64\r\n";
    $corpo .= "Content-Disposition: attachment; filename=\"FORMULÁRIO ELETRO AURORA\"\r\n\r\n";
    $corpo .= chunk_split(base64_encode($arquivo2));
    $corpo .= "--{$limite}\r\n";

    $corpo .= "Content-Type: {$arquivo3_tipo}; name=\"{$arquivo3_nome}\"\r\n";
    $corpo .= "Content-Transfer-Encoding: base64\r\n";
    $corpo .= "Content-Disposition: attachment; filename=\"DOCUMENTO DO CLIENTE\"\r\n\r\n";
    $corpo .= chunk_split(base64_encode($arquivo3));
    $corpo .= "--{$limite}\r\n";

    $corpo .= "Content-Type: {$arquivo4_tipo}; name=\"{$arquivo4_nome}\"\r\n";
    $corpo .= "Content-Transfer-Encoding: base64\r\n";
    $corpo .= "Content-Disposition: attachment; filename=\"PROPOSTA COMERCIAL\"\r\n\r\n";
    $corpo .= chunk_split(base64_encode($arquivo4));
    $corpo .= "--{$limite}\r\n";

    $corpo .= "Content-Type: {$arquivo5_tipo}; name=\"{$arquivo5_nome}\"\r\n";
    $corpo .= "Content-Transfer-Encoding: base64\r\n";
    $corpo .= "Content-Disposition: attachment; filename=\"{$arquivo5_nome}\"\r\n\r\n";
    $corpo .= chunk_split(base64_encode($arquivo5));
    $corpo .= "--{$limite}\r\n";
    
    $corpo .= "Content-Type: {$arquivo6_tipo}; name=\"{$arquivo6_nome}\"\r\n";
    $corpo .= "Content-Transfer-Encoding: base64\r\n";
    $corpo .= "Content-Disposition: attachment; filename=\"{$arquivo6_nome}\"\r\n\r\n";
    $corpo .= chunk_split(base64_encode($arquivo6));
    $corpo .= "--{$limite}\r\n";
    
     // Enviar o email
    if (mail($para, $assunto, $corpo, $cabecalhos)) {
      echo "<script>alert('EMAIL ENVIADO COM SUCESSO!');</script>";
    } else {
      echo 'Deu certo';
    }
  } else {
    echo "<script>alert('ENVIE TODOS OS ARQUIVOS NECESSÁRIOS!');</script>";
  }
  
}

?>
<body style="background: rgb(2,0,36);
background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,9,121,1) 0%, rgba(0,212,255,1) 100%);">
<form method="post" enctype="multipart/form-data" style="padding: 5%; border-color: black; border-style: solid; border-radius: 10pt; margin-top: 5%; background-color: #fff;" >
  <div style="text-align: center; align-items: center; align-content: center;">
    <img src="/dist/logo_ea-removebg-preview.png" height="10%" >
    </div>
  
  <h2>Envie seus arquivos para contrato:</h2>
  <div class="form-group">
    <label for="arquivo1">Conta de energia: - OBRIGATÓRIO</label>
    <input type="file" id="arquivo1" name="arquivo1">
  </div>
  <div class="form-group">
    <label for="arquivo2">Formulário: - OBRIGATÓRIO</label>
    <input type="file" id="arquivo2" name="arquivo2">
  </div>
  <div class="form-group">
    <label for="arquivo3">RG ou CNH do cliente: - OBRIGATÓRIO</label>
    <input type="file" id="arquivo3" name="arquivo3">
  </div>
  <div class="form-group">
    <label for="arquivo4">PROPOSTA COMERCIAL: - OBRIGATÓRIO</label>
    <input type="file" id="arquivo4" name="arquivo4">
  </div>
  <div class="form-group">
    <label for="arquivo5">CONTRATO SOCIAL - (OBRIGATÓRIO PARA CNPJ)</label>
    <input type="file" id="arquivo5" name="arquivo5">
  </div>
  
  <div class="form-group">
    <label for="arquivo5">RELATÓRIO ENGENHARIA CIVIL - (OPCIONAL)</label>
    <input type="file" id="arquivo6" name="arquivo6">
  </div>
  <button type="submit" name="enviar">Enviar E-mail</button>
</form>
</body>

    <meta name="viewport" content="width=device-width, initial-scale=1">



<style>
form {
  max-width: 500px;
  margin: 0 auto;
}

h2 {
  text-align: center;
  margin-bottom: 30px;
  font-family: Arial, Helvetica, sans-serif;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
  font-family: Arial, Helvetica, sans-serif;
}

input[type="file"] {
  display: block;
  padding: 5px;
  border: 1px solid #ccc;
  width: 100%;
  box-sizing: border-box;
}

button[type="submit"] {
  background-color: #4CAF50;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  margin-top: 20px;
  display: block;
  width: 100%;
}


</style>
    
